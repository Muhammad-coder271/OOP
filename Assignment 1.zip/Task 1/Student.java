//Muhammad bin Abid
//SP25-BCS-094

public class Student {
    private String name;
    private String cgpa;   
    private String email;

       public void setName(String newName) {
        name = newName;
    }

    
    public String getName() {
        return name;
    }

    
    public void setCgpa(String newCgpa) {
        cgoa = newCgpa;
    }

  
    public String getCgpa() {
        return cgpa;
    }

   
    public void setEmail(String newEmail) {
        email = newEmail;
    }

    
    public String getEmail() {
        return email;
    }
}
