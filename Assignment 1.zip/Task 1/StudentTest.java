
public class StudentTest {
    public static void main(String[] args) {
        
        Student s = new Student();

       
        s.setName("Abid");
        s.setCgpa("3.75");    
        s.setEmail("muhammadbinabid@gmail.com");

        // Display values
       
        System.out.println("Name: " + s.getName());
        System.out.println("CGPA: " + s.getCgpa());
        System.out.println("Email: " + s.getEmail());
    }
}
